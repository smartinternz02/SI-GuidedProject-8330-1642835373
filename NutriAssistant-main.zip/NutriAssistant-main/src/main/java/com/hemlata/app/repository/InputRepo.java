package com.hemlata.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.hemlata.app.model.Input;

public interface InputRepo extends CrudRepository<Input,String>{

}
